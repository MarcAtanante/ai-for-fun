import flask
import json
import os
from flask import send_from_directory, request, render_template, jsonify

# Flask app should start in global layout
app = flask.Flask(__name__)

@app.route('/favicon.ico')
def favicon():
    return send_from_directory(os.path.join(app.root_path, 'static'),
                               'favicon.ico', mimetype='image/favicon.png')
@app.route('/')
@app.route('/home')
def home():
    return render_template('home.html')

@app.route('/webhook', methods=['POST'])
def webhook():
    req = request.get_json(force=True)
    intent_name = req['queryResult']['queryText']

    # Conditions
    if 'location' in intent_name.lower():
        response = 'Building #4, ABC Street, Brgy.123'
    elif 'available' in intent_name.lower():
        response = 'Yes, it is available.'
    elif 'deliver' in intent_name.lower():
        response = 'Yes, we have our own riders and rates are determined depending on your location.'
    elif 'hours' in intent_name.lower():
        response = 'We are open from 12pm to 12am.'
    elif 'menu' in intent_name.lower():
        response = 'Please visit this link: https://web.abcd.com/photo/?abid=12345&set=pb.5567.-1111.'
    else:
        response = 'Sorry I did not understand that. Please wait for our live agent to assist you.'

    return jsonify({'fulfillmentText': response})

if __name__ == "__main__":
    app.secret_key = 'ItIsASecret'
    app.debug = True
    app.run()